/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Business.*;
import Data.Access;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author JHill
 */
@WebServlet(urlPatterns = {"/checkoutServlet"})
public class checkoutServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("CheckoutServlet Called");
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        System.out.println(action);
        Cart cart = new Cart();
        cart = (Cart) session.getAttribute("cart");
        System.out.println(cart.getTotal());
        
        if (action.equals("checkout")) {
            session.setAttribute("cart", cart);
            System.out.println("Running checkout");
            response.sendRedirect(request.getContextPath() + "/Checkout/submit-order.jsp");
        } else if (action.equals("removeItem")) {
            System.out.println("Running Removal");
            int row = (Integer.parseInt(request.getParameter("row")) - 1);
            System.out.println(row);
            cart.removeItem(cart.getItems().get(row));
            session.setAttribute("cart", cart);
            response.sendRedirect(request.getContextPath() + "/Checkout/shoppingcart.jsp");
        } else if (action.equals("placeorder")) {
            System.out.println("Placing Order");
            String cardnumber = request.getParameter("cardnum");
            Customer c1 = (Customer) session.getAttribute("c1");
            c1.setCardInfo(cardnumber);
            cart.placeOrder(c1.getId());
            c1.selectDB(c1.getId());
            int lastorder = c1.getHistory().getOrders().size() - 1;
            int confirmation = c1.getHistory().getOrders().get(lastorder).getOrderNo();
            session.setAttribute("confirmation", confirmation);
            response.sendRedirect(request.getContextPath() + "/Checkout/order-confirmation.jsp");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
